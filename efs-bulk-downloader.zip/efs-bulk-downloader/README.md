# eFS Bulk Downloader

Chrome extension that bulk-downloads documents from the Malaysian Courts e-Filing System (eFS) inbox, sorted into a folder per case.

## Install (one time)

1. Unzip this folder somewhere permanent (e.g. Documents\efs-bulk-downloader). Don't delete it afterwards — Chrome loads it from there.
2. In Chrome, go to `chrome://extensions`.
3. Turn on **Developer mode** (top right).
4. Click **Load unpacked** and pick the unzipped folder.
5. Optional: pin it from the puzzle-piece menu. Clicking the icon opens the "Sedia untuk Diekstrak" inbox.

## Use

1. Log in to eFS and open **Sedia untuk Diekstrak** (or **Peti Masuk**).
2. Click **⬇ eFS Bulk Download** (bottom right).
3. Set the date range (default: last 30 days). Optionally filter by case number.
4. **1. Scan inbox** — opens each message in range and lists its documents, grouped by case.
5. Tick what you want (new documents are ticked by default), then **2. Download selected**.
6. **Export CSV** saves an index: date, case no., document, serial no. and extraction code.

Files are saved to your Downloads folder as:

```
eFS/<Case No>/<YYYY-MM-DD> <Document name>.pdf
```

Case numbers use `-` in place of `/` (Windows doesn't allow `/` in names).

## Download a whole case file

1. Open a case (CaseDetails page) in eFS.
2. Click the green **⬇ Download all case files** button (bottom right).
3. Untick anything you don't want, then **Download selected**.

Each file is named by its enclosure number and document category, not the original upload name:

```
eFS/<Plaintiff> v <Defendant>/001_Writ Saman.pdf
eFS/<Plaintiff> v <Defendant>/002_Pernyataan Tuntutan.pdf
```

The page reloads once per file while this runs. That's how eFS releases each document, so leave the tab alone until it says **Done** (roughly 3–4 seconds per file). If you close the tab midway, reopen the case and click Download again; files already saved are skipped.

## Good to know

- Works through your own logged-in session; it only sees what your account can see.
- Scanning opens each message, which marks it as read in eFS.
- Scanned messages are cached, so re-scanning the same range is near-instant.
- "Skip already downloaded" remembers files across sessions. "Reset history" clears that memory.
- Keep the delay at 1,000 ms or more to stay gentle on the court's server.
- If eFS logs you out mid-run, downloads stop with a "session may have expired" message. Log in again and rerun; finished files are skipped.
- The scan assumes the inbox is sorted newest first (eFS's default) and stops at the first message older than the From date.
- If eFS changes its page layout, the extension may need updating.
